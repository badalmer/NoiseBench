# Chromatron
Files and Code associated to Chromatron. The Automated paint mixer. Powered by Arduino
